package com.example.a777;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URI;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity  {



    private Button button;
    private EditText userName;
    private TextView user;
    private TextView karma;
    private TextView commentsCount;
    private TextView commentsValue;
    private TextView work;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        userName = findViewById(R.id.userName);
        user = findViewById(R.id.user);
        karma = findViewById(R.id.karma);
        commentsCount = findViewById(R.id.commentsCount);
        commentsValue = findViewById(R.id.commentsVolume);
        work = findViewById(R.id.work);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Если ничего не ввели в поле, то выдаем всплывающую подсказку
                if (userName.getText().toString().trim().equals("")) {


                    Toast.makeText(MainActivity.this, R.string.no_user_input, Toast.LENGTH_LONG).show();

                }

                else{
                    // Если ввели, то формируем ссылку для получения погоды
                    String user1 = userName.getText().toString();
                    String url1 = "https://d3.ru/api/users/" + user1 + "/comments/";

                    user.setText(user1);
                    karma.setText(url1);

                    // Запускаем класс для получения погоды


                }

            }
        });


    }
    public class RetrofitClient {

        private static RetrofitClient instance = null;
        private Api myApi;

        private RetrofitClient() {
            Retrofit retrofit = new Retrofit.Builder().baseUrl(Api.BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            myApi = retrofit.create(Api.class);
        }

        public static synchronized RetrofitClient getInstance() {
            if (instance == null) {
                instance = new RetrofitClient();
            }
            return instance;
        }

        public Api getMyApi() {
            return myApi;
        }
    }
            
            


}